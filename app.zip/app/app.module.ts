﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AdvertisementComponent } from './app.advertisementComponent';
import { SearchByArea } from './app.searchByArea';
import { SearchByPincode } from './app.searchByPincode';
import { HttpClientModule,HttpParams } from '@angular/common/http';

const route: Routes = [
    // { path: "",redirectTo:"show", pathMatch: 'full' },
    { path: "addadvertisement", component: AdvertisementComponent },
    { path: "searchbyarea", component: SearchByArea },
    { path: "searchbypincode", component: SearchByPincode },
]


@NgModule({
    imports: [
        BrowserModule,HttpClientModule, FormsModule, RouterModule.forRoot(route)

    ],
    declarations: [
        AppComponent, AdvertisementComponent, SearchByArea, SearchByPincode
    ],
    providers: [],
    bootstrap: [AppComponent]
})

export class AppModule { }
﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { AddProduct } from './app.addProduct';
import { ShowProduct } from './app.showProduct';
import { SearchProduct } from './app.searchProduct';
import { UpdateProduct } from './app.updateProduct';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

const route: Routes = [
    { path: "add", component: AddProduct },
    { path: "show", component: ShowProduct },
    { path: "search", component: SearchProduct },
    { path: "update", component: UpdateProduct }
]


@NgModule({
    imports: [
        BrowserModule, FormsModule, RouterModule.forRoot(route)

    ],
    declarations: [
        AppComponent, AddProduct, ShowProduct, SearchProduct, UpdateProduct
    ],
    providers: [],
    bootstrap: [AppComponent]
})

export class AppModule { }
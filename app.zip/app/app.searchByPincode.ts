import {Component} from '@angular/core';
import { AdvertisementService } from './app.advertisementService';
import { Advertisement } from './app.advertisement';

@Component({
selector:'pincode-ad',
templateUrl:'app.searchByPincode.html'



})
export class SearchByPincode{

    advertisements: Advertisement[];
    area:string;
    model: string;
    constructor(private  parkingservice: AdvertisementService) { }
    ngOnInit() { }
    searchAdByPincode() {
        console.log("search area...."+this.model);
        this.parkingservice.searchAdByPincode(this.model).subscribe((data: any) => this.advertisements = data);
    }
} 
  

import { Advertisement } from './app.advertisement';

export class Agent {
    phoneNumber: number;
    name: string;
    advertisement: Advertisement
}
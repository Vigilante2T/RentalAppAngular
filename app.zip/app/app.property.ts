


export class Property {
    propertyId: number;
    area: string;
    pincode: number;
    buildingName: string;
    flatNumber: number;
    commission: number;
    flatType: string

}
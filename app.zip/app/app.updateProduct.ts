import {Component} from '@angular/core';


@Component({
selector:'update-prod',
templateUrl:'app.updateProduct.html'



})
export class UpdateProduct{
} 
  
import { Component, OnChanges, OnInit } from '@angular/core';
import { AdvertisementService } from './app.advertisementService';
import { Agent } from './app.agent';

@Component({
    selector: 'prod-app',
    templateUrl: 'app.agent.html'
})
export class AdvertisementComponent implements OnInit {

    products: Agent[];
    model: any = {};

    pro: any = {
        "phoneNumber": 852741963,
        "name": "Check",
        "advertisement[0].advertisement_id": 121,
        "advertisement[0].area": "Checkcheck",
        "advertisement[0].pincode": 456456,
        "advertisement[0].phoneNumber": 852741963,
        "advertisement[0].flatType": "3bhk",
        "advertisement[0].property.property_id": 212,
        "advertisement[0].property.area": "Checkcheck",
        "advertisement[0].property.pincode": 456456,
        "advertisement[0].property.buildingName": "Checkch",
        "advertisement[0].property.flatNumber": 212,
        "advertisement[0].property.commission": 12,
        "advertisement[0].property.flatType": "3bhk"
    }
    constructor(private proService: AdvertisementService) {
        console.log("In product Constructor");
    }

    ngOnInit() {
        console.log("in on init");
        // this.proService.getAllProduct().subscribe((data:Agent[])=>this.products=data);

    }
    addProduct() {
        console.log(this.model);

        this.proService.addAllProduct(this.model).subscribe((data: any) => console.log(data));
    }

}
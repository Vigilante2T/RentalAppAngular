import { Component } from '@angular/core';


@Component({
    selector: 'add-prod',
    templateUrl: 'app.addProduct.html'



})
export class AddProduct {
}

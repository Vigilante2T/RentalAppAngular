import { Property } from './app.property';


export class Advertisement {
    advertisementId: number;
    area: string;
    pincode: number;
    phoneNumber: number;
    flatType: string;
    property: Property
}
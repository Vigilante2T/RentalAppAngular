import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
// import { Product } from './app.product';


@Injectable({
    providedIn: 'root'
})
export class AdvertisementService {
    opionts = {
        headers: new HttpHeaders({
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
            'Access-Control-Allow-oRIGIN': '*'
        })
    }

    constructor(private http: HttpClient) {
        console.log("inside  ad service.....");
    }

    //     getAllProduct(){
    //        return this.http.get("http://localhost:9098/product/show");
    // }

    addAllProduct(prod: any) {
        console.log("product console..." + prod);

        let input = new FormData();

        input.append("phoneNumber", prod.phoneNumber);
        input.append("name", prod.name);
        input.append("advertisement[0].advertisement_id", prod.advertisementId);
        input.append("advertisement[0].area", prod.advertisementArea);
        input.append("advertisement[0].pincode", prod.advertisementPincode);
        input.append("advertisement[0].phoneNumber", prod.phoneNumber);
        input.append("advertisement[0].flatType", prod.advertisementFlatType);
        input.append("advertisement[0].property.property_id", prod.propertyId);
        input.append("advertisement[0].property.area", prod.advertisementArea);
        input.append("advertisement[0].property.pincode", prod.advertisementPincode);
        input.append("advertisement[0].property.buildingName", prod.propertyBuildingName);
        input.append("advertisement[0].property.flatNumber", prod.propertyFlatNumber);
        input.append("advertisement[0].property.commission", prod.propertyCommission);
        input.append("advertisement[0].property.flatType", prod.advertisementFlatType);


        console.log("input console..." + input);
        return this.http.post("http://localhost:9098/advertisement/addAd", input);
    }

    // searchAllVehicle(vehicles: any) {
    //     let  input = new  FormData();
    //     input.append("advertisement[0].area", vehicles.advertisementArea);
    //     return  this.http.post<any>("http://localhost:9098/advertisement/searchArea", input);
    // }

    searchAllVehicle(category:string){
        let params = new HttpParams().set("area",category);
        return this.http.get("http://localhost:9098/advertisement/searchArea",{params: params});
        } 

        searchAdByPincode(category:string){
            let params = new HttpParams().set("pincode",category);
            return this.http.get("http://localhost:9098/advertisement/searchPincode",{params: params});
            } 
    
}
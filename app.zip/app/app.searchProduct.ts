import  { Component }  from  '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
    selector: 'search-prod',
    templateUrl: 'app.searchProduct.html'
})
export  class  SearchProduct {
    constructor(private activate:ActivatedRoute){
        this.activate.snapshot.params['id'];
    }
}

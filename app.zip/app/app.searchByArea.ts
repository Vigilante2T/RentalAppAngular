import { Component } from '@angular/core';
import { AdvertisementService } from './app.advertisementService';
import { Advertisement } from './app.advertisement';

@Component({
    selector: 'area-ad',
    templateUrl: 'app.searchByArea.html'



})
export class SearchByArea {

    advertisements: Advertisement[];
    area:string;
    model: string;
    constructor(private  parkingservice: AdvertisementService) { }
    ngOnInit() { }
    searchAd() {
        console.log("search area...."+this.model);
        this.parkingservice.searchAllVehicle(this.model).subscribe((data: any) => this.advertisements = data);
    }
}
